package TestClass;

import org.testng.annotations.Test;

import PageClasses.LoginPage;
import Utilities.BaseClass;

public class LoginTest extends BaseClass {
	
	@Test(priority=0)
	public static void executeLogin() throws InterruptedException
	{
		driver.findElement(LoginPage.hamburgerMenu()).click();
		driver.findElement(LoginPage.loginBtn()).click();
		driver.findElement(LoginPage.userName()).sendKeys("John Doe");
		driver.findElement(LoginPage.password()).sendKeys("ThisIsNotAPassword");
		driver.findElement(LoginPage.submitBtn()).click();
		int x=9/0;
		System.out.println(x);
		Thread.sleep(5000);
		
		
	}
	

}
