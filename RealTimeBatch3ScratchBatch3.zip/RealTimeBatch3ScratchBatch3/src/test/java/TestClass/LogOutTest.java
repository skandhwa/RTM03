package TestClass;

import org.openqa.selenium.NoSuchElementException;
import org.testng.annotations.Test;

import PageClasses.LogOutPage;
import Utilities.BaseClass;

public class LogOutTest extends BaseClass {
	
	@Test(retryAnalyzer=Utilities.RetryAnalyzer.class)
	public static void logOut() throws InterruptedException
	{
		LoginTest.executeLogin();
		driver.findElement(LogOutPage.hamburgerMenu()).click();
		driver.findElement(LogOutPage.logoutBtn()).click();
		driver.findElement(LogOutPage.hamburgerMenu()).click();
	boolean flag1=	driver.findElement(LogOutPage.homeIcon()).isDisplayed();
	boolean flag2=	driver.findElement(LogOutPage.loginIcon()).isDisplayed();
	if(flag1==true && flag2==true)
	{
		System.out.println("User is logged out from application");
	}
	
	else
	{
		throw new NoSuchElementException("Icons are not present");
	}
	
	}
	
	

}
